import {create} from 'zustand';
const initialLanguage=localStorage.getItem('tiny-language')||(navigator.language.startsWith('en')?'en':'th');
export const useStore=create(set=>({lang:initialLanguage,room:null,me:null,connected:false,busy:false,error:'',iceServers:[],offset:0,setLang:lang=>{localStorage.setItem('tiny-language',lang);set({lang});},patch:state=>set(state)}));
